﻿namespace Aeroporti.Dto
{
    public class Volo
    {
        public string IdVolo { get; set; }
        public string GiornoSett { get; set; }
        public Aeroporto CittaPartenza { get; set; }
        public TimeSpan OraPart { get; set; }
        public Aeroporto CittaArrivo { get; set; }
        public TimeSpan OraArr { get; set; }
        public Aereo Aereo { get; set; }

        public override string ToString()
        {
            return $"IdVolo: {IdVolo} Giorno: {GiornoSett} CittaPart: {CittaPartenza.Citta} OraPart: {OraPart} CittaArr: {CittaArrivo.Citta} OraArr: {OraArr} Aereo: {Aereo.TypoAereo}";
        }
    }
}
