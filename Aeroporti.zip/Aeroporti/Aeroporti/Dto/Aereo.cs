﻿namespace Aeroporti.Dto;

public class Aereo
{
    public string TypoAereo { get; set; }
    public int NumPasseggeri { get; set; }
    public int QtaMerci { get; set; }
}