﻿namespace Aeroporti.Dto;

public class Aeroporto
{
    public string Citta { get; set; }
    public string Nazione { get; set; }
    public int NumPiste { get; set; }
}