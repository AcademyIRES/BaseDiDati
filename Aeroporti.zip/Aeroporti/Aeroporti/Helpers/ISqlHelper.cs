﻿using Aeroporti.Dto;

namespace Aeroporti.Helpers;

public interface ISqlHelper
{
    List<Volo> GetVoloList();
    List<Volo> GetVoliByCity(string citta);

    Dictionary<int, string> GetCittaPart();
}