﻿using Aeroporti.Dto;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Aeroporti.Helpers
{
    public class SqlHelper : ISqlHelper
    {
        private readonly string _connectionString;
        private string _query = @"SELECT v.IdVolo
                                  ,v.GiornoSett
                                  ,v.CittàPart
	                              ,a1.Nazione AS NazionePart
	                              ,a1.NumPiste AS NumPistePart 
                                  ,v.OraPart
                                  ,v.CittàArr
	                              ,a2.Nazione AS NazioneArr
	                              ,a2.NumPiste AS NumPisteArr
                                  ,v.OraArr
                                  ,v.TipoAereo
	                              ,a.NumPasseggeri
	                              ,a.QtaMerci
                              FROM Volo v
                              JOIN Aeroporto a1 ON a1.Città = v.CittàPart
                              JOIN Aeroporto a2 ON a2.Città = v.CittàArr
                              JOIN Aereo a ON a.TipoAereo = v.TipoAereo";


        public SqlHelper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Volo> GetVoloList()
        {
            return GetListVolo(_query, null);
        }




        public List<Volo> GetVoliByCity(string citta)
        {
            var query = $"{_query} WHERE v.CittàPart = @citta";
            return GetListVolo(query, citta);
        }

        public Dictionary<int, string> GetCittaPart()
        {
            var query = @"SELECT DISTINCT CittàPart FROM Volo";
            var cittaDict = new Dictionary<int, string>();
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand(query, connection);
            connection.Open();
            var reader = command.ExecuteReader();
            var count = 0;
            while (reader.Read())
            {
                var citta = reader.GetString("CittàPart");
                cittaDict[count++] = citta;
            }

            return cittaDict;
        }

        private List<Volo> GetListVolo(string query, string citta)
        {
            var listVolo = new List<Volo>();
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand(query, connection);
            if (citta != null)
                command.Parameters.AddWithValue("@citta", citta);
            connection.Open();
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                var volo = GetVolo(reader);
                listVolo.Add(volo);
            }

            return listVolo;
        }

        private Volo GetVolo(SqlDataReader reader)
        {
            var volo = new Volo
            {
                IdVolo = reader.GetString("IdVolo"),
                GiornoSett = reader.GetString("GiornoSett"),
                CittaPartenza = new Aeroporto
                {
                    Citta = reader.GetString("CittàPart"),
                    Nazione = reader.GetString("NazionePart"),
                    NumPiste = reader.GetInt32("NumPistePart")
                },
                OraPart = reader.GetTimeSpan(reader.GetOrdinal("OraPart")),
                CittaArrivo = new Aeroporto
                {
                    Citta = reader.GetString("CittàArr"),
                    Nazione = reader.GetString("NazioneArr"),
                    NumPiste = reader.GetInt32("NumPisteArr")
                },
                OraArr = reader.GetTimeSpan(reader.GetOrdinal("OraArr")),
                Aereo = new Aereo
                {
                    TypoAereo = reader.GetString("TipoAereo"),
                    NumPasseggeri = reader.GetInt32("NumPasseggeri"),
                    QtaMerci = reader.GetInt32("QtaMerci")
                }
            };
            return volo;
        }
    }
}
