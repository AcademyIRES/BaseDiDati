﻿


using Aeroporti.Helpers;
using Microsoft.Data.SqlClient;

var connectionString = @"Server=localhost\SQLEXPRESS; Database=Aeroporti; Integrated Security=true; TrustServerCertificate=True";
Console.WriteLine("Citta disponibili: ");
var sqlHelper = new SqlHelper(connectionString);
var dictCitta = sqlHelper.GetCittaPart();
foreach (var citta in dictCitta)
{
    Console.WriteLine($"[{citta.Key}] {citta.Value}");
}
Console.WriteLine("Inserire il numero relativo alla citta di partenza: ");
var indexCitta = Console.ReadLine();

try
{
    var cittaPart = dictCitta[int.Parse(indexCitta)];
    var listVolo = sqlHelper.GetVoliByCity(cittaPart);

    foreach (var volo in listVolo)
    {
        Console.WriteLine(volo);
    }
}
catch (SqlException e)
{
    Console.WriteLine("Errore: Problema durante la lettura dei dati..");
}
catch (KeyNotFoundException e)
{
    Console.WriteLine("Errore: Scelta non prevista..");
}
catch (Exception e)
{
    Console.WriteLine("Errore generico..");
}

Console.ReadKey();
